#!/bin/bash
# runs all the tests

make

for D in Tests/*; do
    if [ -d "${D}" ]; then
        for s in $D/*; do
            echo $s
            1521 emu -E $D.s < $s > expected
            ./emu -E $D.s < $s > out
            diff expected out
            if [ $? -ne 0 ]; then
                echo "Test failed $s"
                exit 1
            fi
        done
    fi
done
